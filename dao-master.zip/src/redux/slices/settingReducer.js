const initialState = {
  isLoading: false,
};

const settingReducer = (state = initialState, action) => {
  switch (action.type) {
    default:
      return initialState;
  }
};

export default settingReducer;
